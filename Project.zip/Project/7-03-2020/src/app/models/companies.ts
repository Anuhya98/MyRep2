export class Company{
    id:number;
    companyname:string;
    turnover:number;
    companyceoname:string;
    selectstockexchange:string;
    selectsector:string;
    aboutcompany:string;
}