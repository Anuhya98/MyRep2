export class StockExchange{
    id:number;
    stockexchange:string;
    brief:string;
    contactaddress:string;
    remarks:string;
}