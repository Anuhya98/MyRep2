export class IPO{
    id:number;
    companyname:string;
    stockexchange:string;
    pricepershare:number;
    totalnoofshares:number;
    opendatetime:Date;
}