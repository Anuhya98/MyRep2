export class User
{
    id:number;
    username:string;
    email:string;
    phoneno:number;
    password:string;
    confirmpassword:string;
    regStatus:string;
    active:string;
}