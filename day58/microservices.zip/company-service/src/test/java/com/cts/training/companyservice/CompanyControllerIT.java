package com.cts.training.companyservice;

import java.util.Arrays;

import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.context.SpringBootTest.WebEnvironment;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@SpringBootTest(classes=CompanyServiceApplication.class,webEnvironment = WebEnvironment.RANDOM_PORT)
@ExtendWith(SpringExtension.class)
public class CompanyControllerIT {
	@LocalServerPort
	private int port;
	HttpHeaders headers=new HttpHeaders();
	TestRestTemplate restTemplate=new TestRestTemplate();
	
	@Test
	void getTest() {
		String url="http://localhost:"+port+"/company";
		System.out.println("Port::"+url);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity=new HttpEntity<String>(null,headers);
		ResponseEntity<String> response=restTemplate.exchange(url, HttpMethod.GET,entity,String.class);
		String expected="{\"id\":134,\"companyname\":\"TCS\",\"turnover\":8500,\"companyceoname\":\"Tata\",\"boardofdirectors\":\"Pavitra\",\"selectstockexchange\":\"nse\",\"selectsector\":\"it\",\"aboutcompany\":\"Indian mnc\"}";
		System.out.println("TEST::Response Body:::"+response.getBody());
		assertTrue(response.getBody().contains(expected));
	}
	
	@Test
	public void getbyidtest() throws Exception
	{
		String url="http://localhost:"+port+"/company/134";
		System.out.println("Port is ::"+url);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		HttpEntity<String> entity=new HttpEntity<String>(null,headers);
		ResponseEntity<String> response=restTemplate.exchange(url,HttpMethod.GET,entity,String.class);
		String expected="{\"id\":134,\"companyname\":\"TCS\",\"turnover\":8500,\"companyceoname\":\"Tata\",\"boardofdirectors\":\"Pavitra\",\"selectstockexchange\":\"nse\",\"selectsector\":\"it\",\"aboutcompany\":\"Indian mnc\"}";
		System.out.println("TEST :: Response Body :::: " +response.getBody());
		assertTrue(response.getBody().contains(expected));
		
	}
	
	@Test
	public void addtest() throws Exception
	{
		String url="http://localhost:"+port+"/company";
		System.out.println("Port is ::"+url);
		headers.setAccept(Arrays.asList(MediaType.APPLICATION_JSON));
		Company company=new Company(150, "Infoview", 2500, "Gupta", "Shukla", "others", "it", "Chennai");
		HttpEntity<Company> entity=new HttpEntity<Company>(company,headers);
		ResponseEntity<String> response=restTemplate.exchange(url,HttpMethod.POST,entity,String.class);
		String expected="\"companyname\":\"Infoview\",\"turnover\":2500,\"companyceoname\":\"Gupta\",\"boardofdirectors\":\"Shukla\",\"selectstockexchange\":\"others\",\"selectsector\":\"it\",\"aboutcompany\":\"Chennai\"}";
		assertTrue(response.getBody().contains(expected));
		
	}
	

}
