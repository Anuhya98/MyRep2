package com.cts.training;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class CtsDemoRestController {
	
	@GetMapping("/staysafe")
	public String sayBye() {
		return "Beware of Carona";
	}
	
	@GetMapping("steps")
	public List<String> safetymeasures(){
		return new ArrayList<String>(Arrays.asList("Sanitizer","Hot water","etc"));
	}

}
