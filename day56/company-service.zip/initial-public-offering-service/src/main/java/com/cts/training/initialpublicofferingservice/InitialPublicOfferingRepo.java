package com.cts.training.initialpublicofferingservice;

import org.springframework.data.jpa.repository.JpaRepository;



public interface InitialPublicOfferingRepo extends JpaRepository<InitialPublicOffering, Integer>{

}
