package com.cts.training;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CtsServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(CtsServiceApplication.class, args);
	}

}
