package com.cts.training;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CtsAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
