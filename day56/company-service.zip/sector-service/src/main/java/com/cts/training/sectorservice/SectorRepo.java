package com.cts.training.sectorservice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SectorRepo extends JpaRepository<Sector, Integer>{

}
