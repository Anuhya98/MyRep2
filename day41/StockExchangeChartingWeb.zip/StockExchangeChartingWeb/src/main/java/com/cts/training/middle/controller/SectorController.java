package com.cts.training.middle.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import com.cts.project.dao.SectorDao;
import com.cts.project.model.Sector;

@Controller
public class SectorController 
{
	@Autowired
	SectorDao sectorDAO;
	
	@GetMapping("/sector-home")
	public String sectorPage(Model model)
	{
		model.addAttribute("sector", new Sector());
		List<Sector> sectors=sectorDAO.getAllSectors();
		model.addAttribute("list", sectors);
		//User user=new User();
		return "sectors";
	}
	
	@PostMapping("/sector/save")
	//@RequestMapping(value="/user/save", method=RequestMethod.POST)
	public String addSector(@ModelAttribute("sector") Sector sector)
	{
		sectorDAO.addSector(sector);
		return "redirect:/sector-home";
	}
	
	@GetMapping("/sectorremove/{sectorId}")//{}->Path Variable
	public String deleteSector(@PathVariable("sectorId")int sectorId)
	{
		Sector sector=sectorDAO.getSectorById(sectorId);
		sectorDAO.deleteSector(sector);
		return "redirect:/sector-home";
	}

}
