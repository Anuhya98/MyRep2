package com.cts.training.test;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.BeforeClass;
import org.junit.Ignore;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cts.project.dao.SectorDao;
import com.cts.project.model.Sector;

public class SectorUnitTest
{
	private static AnnotationConfigApplicationContext context;
	private static SectorDao sectorDAO;
	private static Sector sector;
	
	@BeforeClass
	public static void init() 
	{
		context=new AnnotationConfigApplicationContext();
		context.scan("com.cts.project");
		context.refresh();
	    sector=(Sector)context.getBean("sector");
		sectorDAO=(SectorDao) context.getBean("sectorDAO");
	  	
	}
	
	@Test
	public void testGetAllSectors() {
		List<Sector> sectors=sectorDAO.getAllSectors();
		assertEquals(2, sectors.size());
	}
	
	@Test
	@Ignore
	public void test_add_sector_success() {
		Sector s=new Sector(61, "textiles", "wonderful");
		assertEquals(true,sectorDAO.addSector(s));
	}
	
	

}
