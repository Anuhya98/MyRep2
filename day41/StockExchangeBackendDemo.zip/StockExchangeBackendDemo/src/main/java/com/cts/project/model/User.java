package com.cts.project.model;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name = "usersbackend")
public class User implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 8817290365227430343L;
	@Id
	@GeneratedValue
	private int id;
	private String username;
	private String email;
	private long phoneno;
	private String password;
	private String confirmpassword;

	
	
	public User() {
		super();
		// TODO Auto-generated constructor stub
	}

	public User(int id, String username, String email, long phoneno, String password, String confirmpassword) {
		super();
		this.id = id;
		this.username = username;
		this.email = email;
		this.phoneno = phoneno;
		this.password = password;
		this.confirmpassword = confirmpassword;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public long getPhoneno() {
		return phoneno;
	}

	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmpassword() {
		return confirmpassword;
	}

	public void setConfirmpassword(String confirmpassword) {
		this.confirmpassword = confirmpassword;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", email=" + email + ", phoneno=" + phoneno + ", password="
				+ password + ", confirmpassword=" + confirmpassword + "]";
	}

}
